// Package config handles all environment variable loading and application configuration.
// It uses the godotenv library to read from a .env file so sensitive keys
// like API credentials are never hard-coded in source code.
package config

import (
	"log"
	"os"

	"github.com/joho/godotenv"
)

// Config holds all configuration values loaded from the environment.
// Add new fields here whenever you need a new environment variable.
type Config struct {
	GeminiAPIKey string // Your Google Gemini API key
	Port         string // The port the HTTP server will listen on
}

// Load reads the .env file from the current directory, then populates
// and returns a Config struct. It fatally exits if the .env file cannot
// be found, because the app cannot function without its credentials.
func Load() *Config {
	// Load the .env file into the process environment.
	// godotenv.Load() looks for ".env" in the working directory.
	if err := godotenv.Load(); err != nil {
		// Log a warning but don't fatal — environment vars might be set
		// directly in production (e.g., Docker / Kubernetes secrets).
		log.Println("Warning: .env file not found, reading from system environment")
	}

	cfg := &Config{
		// os.Getenv returns "" if the variable is not set.
		GeminiAPIKey: os.Getenv("GEMINI_API_KEY"),
		Port:         os.Getenv("PORT"),
	}

	// Validate that the required key is present; crash early with a clear message
	// rather than failing mysteriously later during the first API call.
	if cfg.GeminiAPIKey == "" {
		log.Fatal("FATAL: GEMINI_API_KEY is not set. Please add it to your .env file.")
	}

	// Default the port to 8080 if PORT is not specified in the environment.
	if cfg.Port == "" {
		cfg.Port = "8080"
	}

	return cfg
}
