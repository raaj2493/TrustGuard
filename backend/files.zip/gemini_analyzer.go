// This file contains GeminiAnalyzer — the concrete implementation of the
// Analyzer interface that calls the Google Gemini REST API.
//
// Responsibilities:
//   - Build a carefully-engineered prompt that instructs Gemini to return JSON.
//   - POST that prompt to the Gemini API endpoint.
//   - Decode and validate the HTTP response.
//   - Hand the raw AI text off to utils.ParseAnalysisResult for structured parsing.
package services

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
	"trustguard/models"
	"trustguard/utils"
)

// geminiAPIURL is the REST endpoint for the Gemini 1.5 Flash model.
// Flash is chosen for its speed and cost-efficiency; swap the path segment
// to "gemini-1.5-pro" for higher accuracy on complex inputs.
const geminiAPIURL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

// GeminiAnalyzer holds the configuration needed to call the Gemini API.
// It satisfies the Analyzer interface defined in analyzer.go.
type GeminiAnalyzer struct {
	APIKey     string       // Gemini API key (from the GEMINI_API_KEY env var)
	HTTPClient *http.Client // Reusable HTTP client with a sensible timeout
}

// NewGeminiAnalyzer is a constructor that returns a ready-to-use GeminiAnalyzer.
// Always use this function instead of struct literals to ensure the HTTP client
// is properly configured with a timeout (never use http.DefaultClient in prod).
func NewGeminiAnalyzer(apiKey string) *GeminiAnalyzer {
	return &GeminiAnalyzer{
		APIKey: apiKey,
		HTTPClient: &http.Client{
			Timeout: 30 * time.Second, // Abort if Gemini takes more than 30 s
		},
	}
}

// Analyze implements the Analyzer interface.
// It sends the input text to Gemini with a structured prompt and returns
// a parsed AnalysisResult.
func (g *GeminiAnalyzer) Analyze(text string) (models.AnalysisResult, error) {
	// Step 1 — build the prompt that tells Gemini exactly what we need.
	prompt := g.buildPrompt(text)

	// Step 2 — wrap the prompt in Gemini's expected request envelope.
	reqBody := models.GeminiRequest{
		Contents: []models.GeminiContent{
			{
				Parts: []models.GeminiPart{
					{Text: prompt},
				},
			},
		},
	}

	// Step 3 — marshal the request body to JSON bytes.
	bodyBytes, err := json.Marshal(reqBody)
	if err != nil {
		return models.AnalysisResult{}, fmt.Errorf("failed to marshal Gemini request: %w", err)
	}

	// Step 4 — construct the full URL with the API key as a query parameter.
	// Gemini's REST API accepts authentication via ?key=... in the URL.
	url := fmt.Sprintf("%s?key=%s", geminiAPIURL, g.APIKey)

	// Step 5 — create the HTTP POST request.
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(bodyBytes))
	if err != nil {
		return models.AnalysisResult{}, fmt.Errorf("failed to create HTTP request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")

	// Step 6 — execute the request.
	resp, err := g.HTTPClient.Do(req)
	if err != nil {
		return models.AnalysisResult{}, fmt.Errorf("Gemini API call failed: %w", err)
	}
	defer resp.Body.Close() // Always close the body to avoid resource leaks.

	// Step 7 — read the full response body.
	respBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return models.AnalysisResult{}, fmt.Errorf("failed to read Gemini response body: %w", err)
	}

	// Step 8 — check for non-2xx HTTP status codes (e.g., 401 Unauthorized).
	if resp.StatusCode != http.StatusOK {
		return models.AnalysisResult{}, fmt.Errorf(
			"Gemini API returned status %d: %s", resp.StatusCode, string(respBytes),
		)
	}

	// Step 9 — decode the Gemini response envelope.
	var geminiResp models.GeminiResponse
	if err := json.Unmarshal(respBytes, &geminiResp); err != nil {
		return models.AnalysisResult{}, fmt.Errorf("failed to decode Gemini response: %w", err)
	}

	// Step 10 — guard against empty candidates (Gemini safety filters can block output).
	if len(geminiResp.Candidates) == 0 ||
		len(geminiResp.Candidates[0].Content.Parts) == 0 {
		return models.AnalysisResult{}, fmt.Errorf(
			"Gemini returned no content — the prompt may have been blocked by safety filters",
		)
	}

	// Step 11 — extract the raw text from the first candidate's first part.
	rawText := geminiResp.Candidates[0].Content.Parts[0].Text

	// Step 12 — delegate JSON parsing to the utils package.
	return utils.ParseAnalysisResult(rawText)
}

// buildPrompt crafts the instruction string sent to Gemini.
// The prompt engineering here is critical:
//   - We explicitly ask for JSON so utils.ParseAnalysisResult can decode it.
//   - We define every field, its type, and its allowed values to reduce hallucination.
//   - We ask for no extra prose so the output is parseable.
func (g *GeminiAnalyzer) buildPrompt(text string) string {
	return fmt.Sprintf(`You are a content moderation AI. Analyze the following user-generated text and respond ONLY with a valid JSON object — no markdown, no explanation, just raw JSON.

The JSON must have exactly these fields:
{
  "toxicity": "<low|medium|high>",
  "spam": <true|false>,
  "trust_score": <float between 0.0 and 1.0>,
  "summary": "<one or two sentences explaining your classification>"
}

Definitions:
- toxicity: "low" = civil and respectful, "medium" = mildly offensive or aggressive, "high" = hateful, abusive, or threatening.
- spam: true if the text looks like unsolicited advertising, phishing, or repetitive junk; false otherwise.
- trust_score: 1.0 = completely trustworthy factual content, 0.0 = completely untrustworthy or deceptive.
- summary: brief human-readable justification for your scores.

Text to analyze:
"""
%s
"""`, text)
}
